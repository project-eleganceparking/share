package lab.spring.parking.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lab.spring.parking.dao.UserDAO;
import lab.spring.parking.model.UserVO;
@Service("userService")
public class UserServiceImpl implements UserService{
	@Autowired
	private UserDAO dao;
	
	public UserVO login(String useremail, String userpwd) {
		return dao.login(useremail, userpwd);
	}

	public int addUser(UserVO user) {
		return dao.addUser(user);
	}

}
