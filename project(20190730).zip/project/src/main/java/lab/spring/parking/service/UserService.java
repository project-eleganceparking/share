package lab.spring.parking.service;

import javax.servlet.http.HttpServletRequest;

import lab.spring.parking.model.UserVO;

public interface UserService {
	public UserVO login(String uemail, String upwd);
	public int addUser(UserVO user);
	
}
