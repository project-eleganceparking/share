package lab.spring.parking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import lab.spring.parking.model.UserVO;
import lab.spring.parking.service.UserService;

@RestController
public class UserController {
	@Autowired
	UserService service;
	//Mainȭ�� 
	@RequestMapping("/main.do")
	public ModelAndView main() {
		ModelAndView mav=new ModelAndView();
		mav.setViewName("main");
		return mav;
	}
	@RequestMapping(value="/login.do", method=RequestMethod.POST)
	public ModelAndView login(String uemail, String upwd) {
		ModelAndView mav= new ModelAndView();
		UserVO user =null;
		user=service.login(uemail, upwd);
		mav.addObject("user", user);
		mav.setViewName("main");
		return mav;
	}
	
	//ȸ������
	@RequestMapping(value="/join.do", method=RequestMethod.GET)
	public ModelAndView getjoin() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("join");
		return mav;
	}
	@RequestMapping(value="/join.do", method=RequestMethod.POST)
	public ModelAndView postjoin(UserVO user) {
		ModelAndView mav = new ModelAndView();
		System.out.println(service.addUser(user));
		if(service.addUser(user)>0) {
			mav.setViewName("main");
		}
		return mav;
	}
	
	
}
