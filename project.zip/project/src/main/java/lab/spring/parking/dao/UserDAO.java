package lab.spring.parking.dao;

import java.util.HashMap;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import lab.spring.parking.model.UserVO;

@Repository
public class UserDAO {
	@Autowired
	SqlSession sqlSession;
	
	public UserVO login(String uemail, String upwd) { //�α���
		Object obj=null;
		HashMap<String,String> map= new HashMap<String,String>();
		map.put("uemail", uemail);
		map.put("upwd", upwd);
		obj=sqlSession.selectOne("lab.mybatis.user.UserMapper.login",map);
		return(UserVO) obj;
	}
	
	public int addUser(UserVO user) {//ȸ������
		if(user.getEmail_dns().length()>1) {
			user.setUseremail(user.getEmail()+"@"+user.getEmail_dns());
		}else {
			user.setUseremail(user.getEmail()+"@"+user.getDns_Add());
		}
		//System.out.println("###########"+user.getUseremail()+"###########"+user.getUsername()+"###########"+user.getUserpwd());
		System.out.println(user);
		return sqlSession.insert("lab.mybatis.user.UserMapper.addUser", user);
		
	}
	public int removeUser(final String uid) {
		return sqlSession.delete("lab.mybatis.user.UserMapper.removeUser", uid);
	}
	public UserVO findUser(String uid) {
		return sqlSession.selectOne("lab.mybatis.user.UserMapper.getUser", uid);
	}
}
