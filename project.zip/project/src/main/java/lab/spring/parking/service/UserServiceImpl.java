package lab.spring.parking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lab.spring.parking.dao.UserDAO;
import lab.spring.parking.model.UserVO;
@Service("userService")
public class UserServiceImpl implements UserService{
	@Autowired
	private UserDAO dao;
	
	public UserVO login(String uemail, String upwd) {
		return dao.login(uemail, upwd);
	}

	public int addUser(UserVO user) {
		return dao.addUser(user);
	}

}
