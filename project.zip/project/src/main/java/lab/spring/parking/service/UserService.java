package lab.spring.parking.service;

import lab.spring.parking.model.UserVO;

public interface UserService {
	public UserVO login(String uemail, String upwd);
	public int addUser(UserVO user);
	
}
