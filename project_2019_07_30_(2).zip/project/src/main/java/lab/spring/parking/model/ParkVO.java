package lab.spring.parking.model;

public class ParkVO {

	private String useremail;
	private String parklot; //주차장 관리번호
	
	public String getUseremail() {
		return useremail;
	}
	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}
	public String getParklot() {
		return parklot;
	}
	public void setParklot(String parklot) {
		this.parklot = parklot;
	}

}
