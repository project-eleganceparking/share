package lab.spring.parking.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import lab.spring.parking.model.FavVO;

@Repository
public class FavDAO {

	@Autowired
	SqlSession sqlSession;
	
	public int addFav(FavVO fav) {
		//즐겨찾는 주차장 번호 등록하기
		return sqlSession.insert("lab.mybatis.mapper.FavMapper.addFav", fav);
	}
	public List<FavVO> findFav(String useremail) {
		//useremail에 해당하는 즐찾 주차장 번호 불러오기
		return sqlSession.selectList("lab.mybatis.mapper.FavMapper.getFavinfo", useremail);
	}
	public int deleteFav(final String myfavorite) {
		//myfavoite에 해당하는 즐찾주차장 삭제
		return sqlSession.insert("lab.mybatis.mapper.FavMapper.removeFav", myfavorite);
	}
}
