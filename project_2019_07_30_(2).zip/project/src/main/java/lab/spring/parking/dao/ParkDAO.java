package lab.spring.parking.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import lab.spring.parking.model.ParkVO;


@Repository
public class ParkDAO {

	@Autowired
	SqlSession sqlSession;
	
	
	public int addFav(ParkVO park) {
		//즐겨찾는 주차장 번호 등록하기
		return sqlSession.insert("lab.mybatis.mapper.FavMapper.addPark", park);
	}
	public List<ParkVO> findFav(String useremail) {
		//useremail에 해당하는 즐찾 주차장 번호 불러오기
		return sqlSession.selectList("lab.mybatis.mapper.FavMapper.getParkinfo", useremail);
	}
	public int deletePark(final String parklot) {
		//myfavoite에 해당하는 즐찾주차장 삭제
		return sqlSession.insert("lab.mybatis.mapper.FavMapper.removePark", parklot);
	}
}
