package lab.spring.parking.service;

import java.util.List;

import lab.spring.parking.model.*;


public interface WoowaService {
	
	//user 
	public UserVO login(String uemail, String upwd);
	public int addUser(UserVO user);
	//NOTICE
	public List<NoticeVO> getNoticeList();
	public int addNotice(NoticeVO notice);
	//parklot
	public List<PrkplceVO> findAllList(); //주차장 정보 받아오기
	public List<CommentVO> getCommentList(); //주차장에 대한 댓글 받아오기 (markerid=주차장 seq)
	public int addComment(CommentVO comment); //주차장에 대한 댓글 쓰기
	public int deleteComment(int cid);// 댓글 삭제
}
