package lab.spring.parking.service;

import java.util.List;

import lab.spring.parking.model.*;


public interface WoowaService {
	
	//user 
	public UserVO login(String uemail, String upwd);
	public int addUser(UserVO user);
	//NOTICE 공지사항 
	public List<NoticeVO> getNoticeList();
	public NoticeVO getNotice(int bid);
	public int addNotice(NoticeVO notice);
	public int deleteNotice(int bid); //공지 삭제
	//parklot
	public List<PrkplceVO> findAllList(); //주차장 정보 받아오기
	public List<CommentVO> getCommentList(); //주차장에 대한 댓글 받아오기 (markerid=주차장 seq)
	public int addComment(CommentVO comment); //주차장에 대한 댓글 쓰기
	public int deleteComment(CommentVO comment);// 댓글 삭제
}
