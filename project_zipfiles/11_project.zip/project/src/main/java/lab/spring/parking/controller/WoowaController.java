package lab.spring.parking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.jni.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import lab.spring.parking.model.*;
import lab.spring.parking.service.WoowaService;


@RestController
public class WoowaController {
	
	@Autowired
	WoowaService service;
	
	/* user start*/
	//main page
	@RequestMapping("/main.do")
	public ModelAndView main() {
		ModelAndView mav=new ModelAndView();
		mav.setViewName("home_view");
		return mav;
	}
	@RequestMapping(value="/login.do", method=RequestMethod.POST)
	public ModelAndView loginTry(String useremail, String userpwd, HttpServletRequest request) {
		ModelAndView mav= new ModelAndView();
		UserVO user =null;
		HttpSession session=request.getSession();		
		user=service.login(useremail, userpwd);
		session.setAttribute("user", user);
		System.out.println(user);
		if(user==null) {
			mav.setViewName("home_view(login_fail)");
		}else {
			mav.setViewName("home_view");
		}
		return mav;
	}
	@RequestMapping(value="/logout.do", method=RequestMethod.GET)
	public ModelAndView logoutSuccess( HttpServletRequest request) throws Exception {
		ModelAndView mav= new ModelAndView();
		HttpSession session=request.getSession();
		session.invalidate();
		mav.setViewName("home_view");
		return mav;
	}
	//join page//
	@RequestMapping(value="/join.do", method=RequestMethod.GET)
	public ModelAndView getjoin() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("member");
		return mav;
	}
	@RequestMapping(value="/join.do", method=RequestMethod.POST)
	public ModelAndView joinSuccess(UserVO user) {
		ModelAndView mav = new ModelAndView();
		if(service.addUser(user)>0) {
			mav.setViewName("home_view");
		}
		return mav;
	}
	/* user end */
	
	/* board start */
	@RequestMapping(value="/notice.do", method=RequestMethod.GET)
	public ModelAndView listNotice() {
		ModelAndView mav = new ModelAndView();
		List<NoticeVO> list =null;
		list=service.getNoticeList();
		mav.addObject("list", list);
		mav.setViewName("notice_list");
		return mav;
	}
	
	@RequestMapping(value="/notice_view.do", method=RequestMethod.GET)
	public ModelAndView viewNotice(int bid) {
		ModelAndView mav = new ModelAndView();
		NoticeVO notice=null;
		notice=service.getNotice(bid);
		mav.addObject("notice", notice);
		mav.setViewName("notice_view");
		return mav;
	}
	@RequestMapping(value="/notice_write.do", method=RequestMethod.GET)
	public ModelAndView writeNotice( Model model, HttpServletRequest request, HttpServletResponse response) throws IOException {
		ModelAndView mav = new ModelAndView();
		HttpSession session=request.getSession();
		UserVO user= (UserVO)session.getAttribute("user");
		System.out.println(user);
		if(user==null) {
			System.out.println("로그인이 필요합니다.");
			mav.setViewName("redirect:/notice.do");
		}else if(!user.getIsmanager().equals("Y")){
			model.addAttribute("msg", "관리자만 접근가능한 페이지입니다.");
			System.out.println("x관계자 외 출입x");
			mav.setViewName("redirect:/notice.do");
		}else {
			mav.setViewName("notice_write");
		}
		return mav;
	}
	@RequestMapping(value="/notice_write.do", method=RequestMethod.POST)
	public ModelAndView postNotice( @RequestParam("subject") String sub 
			, @RequestParam("managername") String mng
			, HttpServletRequest request) {
		System.out.println("드러움");
		ModelAndView mav = new ModelAndView();
//		HttpSession session=request.getSession();
//		session.setAttribute("notice", notice);
		System.out.println(mng +" 111111111111111 " +sub);
		//if(service.addNotice(notice)>0) {
			//System.out.println(service.addNotice(notice));
			mav.setViewName("redirect:/notice.do");
		//}
		return mav;
	}
	@RequestMapping(value="/notice_delete.do", method=RequestMethod.POST)
	public ModelAndView deleteNotice(@RequestParam("password") String pwd, int bid, HttpServletRequest request) {
		
		ModelAndView mav = new ModelAndView();
		HttpSession session= request.getSession();
		UserVO user= (UserVO)session.getAttribute("user");
		System.out.println(bid+"번 공지사항 삭제중 : 비번 :"+pwd);
		if(user.getIsmanager().equals("Y")) {
			if(user.getUserpwd().equals(pwd)) {
				service.deleteNotice(bid);
				mav.setViewName("redirect:/notice.do");
			}
		}else {
				mav.setViewName("redirect:/notice.do");
		}
		return mav;
	}
	

	/* board end */
	
	//test
	@RequestMapping(value = "/test1.do")
	public ModelAndView getAll(HttpSession session){
		ModelAndView mav = new ModelAndView();
		List<PrkplceVO> lots = null;
		lots =service.findAllList();
		mav.addObject("lots",lots);
		mav.setViewName("kakaomap2");
		return mav;
		
	}
	
	@RequestMapping(value = "/parking.do")
	public ModelAndView defaultMap(HttpSession session){
		ModelAndView mav = new ModelAndView();
		List<PrkplceVO> lots = null;		
		lots =service.findAllList();
		mav.addObject("lots",lots);
		List<CommentVO> comments= null;
		comments= service.getCommentList();
		mav.addObject("comments", comments);
		mav.setViewName("parking_view");
		return mav;
	}

	/* COMMENT */
	@RequestMapping(value = "/comment.do", method=RequestMethod.POST)
	public ModelAndView addComment(CommentVO comment, HttpServletRequest request){
		ModelAndView mav = new ModelAndView();
		HttpSession session=request.getSession();
		session.setAttribute("comment", comment);
		if(session.getAttribute("user")==null) {//로그인 하지 않은 경우, 댓글작성 권한 없음.
			//model.addAttribute("msg", "로그인이 필요합니다.");
			//model.addAttribute("setview", "parking_view.jsp"); //alert띄우고 싶은데..
			mav.setViewName("redirect:/parking.do");			
		}else{
			if(comment.getPassword()=="") {//비밀번호 입력하지 않음
				mav.setViewName("redirect:/parking.do");
			}else {//댓글 등록 완료
				service.addComment(comment);
				mav.setViewName("redirect:/parking.do");
			}
		}
		return mav;
	}

	@RequestMapping(value = "/delete_comment.do", method=RequestMethod.POST)
	public ModelAndView deleteComment(CommentVO comment, HttpServletRequest request){
		ModelAndView mav = new ModelAndView();
		HttpSession session= request.getSession();
		UserVO user=(UserVO)session.getAttribute("user");
		if(user==null) { //didn't login
			mav.setViewName("redirect:/parking.do");
		}else if(user.getIsmanager().equals("Y")){//매니저는 모든 글 삭제 가능
			if(service.deleteComment(comment)>0) {			
				mav.setViewName("redirect:/parking.do");
			}
		}else if(!comment.getWriter().equals(user.getUsername())) {//이용자와 댓글 작성자와 다르면 삭제하지 못함
			System.out.println("삭제 권한이 없음");
			mav.setViewName("redirect:/parking.do");
		}else{//이용자와 댓글 작성자가 같은 경우 삭제 이행, delete 실행되면 parking뷰 페이지 reload
			if(service.deleteComment(comment)>0) {			
				mav.setViewName("redirect:/parking.do");
			}
		}
		return mav;
	}
	
	
	@RequestMapping(value = "/stop.do") //아직안한거죠?
	public ModelAndView stopMap(HttpSession session){
		ModelAndView mav = new ModelAndView();
		List<PrkplceVO> lots = null;
		lots =service.findAllList();
		mav.addObject("lots",lots);
		mav.setViewName("stop_view");
		return mav;
	}	
	
	@RequestMapping(value = "/MyParkLo.do")
	@ResponseBody
	public String defaultmap(@RequestBody Map<String,Object> point) {
		
		System.out.println(point.get("lat1"));
		
		return "{ \"status\" : 1 }";
	}
}