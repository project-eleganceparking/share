package lab.spring.parking.model;

public class CommentVO {

}
